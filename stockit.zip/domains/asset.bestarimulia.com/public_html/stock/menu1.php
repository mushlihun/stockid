<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<!--
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		-->
		<ul class="nav menu">
			<li class="active"><a href="index.php"><span class="glyphicon glyphicon-signal"></span> Dashboard</a></li>
			<li><a href="barang.php"><span class="glyphicon glyphicon-th"></span> Master Barang</a></li>
			<li><a href="satuan.php"><span class="glyphicon glyphicon-tags"></span> Master Satuan</a></li>
			<li><a href="transaksi1.php"><span class="glyphicon glyphicon-pencil"></span> Transaksi Masuk</a></li>
			<li><a href="transaksi2.php"><span class="glyphicon glyphicon-list-alt"></span> Transaksi Keluar</a></li>
			<li><a href="history1.php"><span class="glyphicon glyphicon-tasks"></span> History Transaksi</a></li>
			<li><a href="laporan1.php"><span class="glyphicon glyphicon-stats"></span> Laporan Stok</a></li>
			<li><a href="backup.php"><span class="glyphicon glyphicon-cloud-download"></span> Backup Database</a></li>
			<li><a href="restore.php"><span class="glyphicon glyphicon-cloud-upload"></span> Restore Database</a></li>
			<li><a href="login/aksilogout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
			<li class="parent ">
				<a href="#">
					<span class="glyphicon glyphicon-list"></span> Dropdown <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span> 
				</a>
				<ul class="children collapse" id="sub-item-1">
					<li>
						<a class="" href="#">
							<span class="glyphicon glyphicon-share-alt"></span> Sub Item 1
						</a>
					</li>
					<li>
						<a class="" href="#">
							<span class="glyphicon glyphicon-share-alt"></span> Sub Item 2
						</a>
					</li>
					<li>
						<a class="" href="#">
							<span class="glyphicon glyphicon-share-alt"></span> Sub Item 3
						</a>
					</li>
				</ul>
			</li>
		</ul>
		<div class="attribution"><a href=""></a></div>
</div><!--/.sidebar-->
